"use client";

import React from "react";
import Navbar from "./Navbar";
import Image from "next/image";
import spotlight from "@/assets/images/spotlight.png";
import MainButton from "./MainButton";
import Particles from "@/components/Particles";

const Hero: React.FC = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center w-full overflow-hidden bg-[#0B0B12]">
      <Navbar />

      <div className="absolute inset-0 z-0">
        <Particles
          className="h-full w-full"
          particleCount={720}
          particleSpread={26}
          speed={0.01}
          particleColors={["#BEB3FE"]}
          particleHoverFactor={1.5}
          alphaParticles={false}
          particleBaseSize={80}
          sizeRandomness={1}
          cameraDistance={32}
          disableRotation={false}
        />
      </div>

      {/* Spotlight Effect - Responsive positioning */}
      <div className="absolute top-1/4 -left-10 translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] md:w-[1000px] md:h-[500px] pointer-events-none z-10">
        <Image
          src={spotlight}
          alt="Spotlight"
          fill
          className="object-cover brightness-125 blur-[5px]"
        />
        <Image
          src={spotlight}
          alt="Spotlight"
          fill
          className="object-cover brightness-125 blur-[200px]"
        />
        <Image
          src={spotlight}
          alt="Spotlight"
          fill
          className="object-cover brightness-125 blur-[100px]"
        />
      </div>

      {/* Main Content */}
      <div className="relative z-30 text-center w-full max-w-4xl px-4 sm:px-6 lg:px-8 pt-24 sm:pt-28 md:pt-32">
        {/* Heading - Responsive */}
        <h1 className="text-2xl sm:text-4xl md:text-4xl lg:text-5xl xl:text-[61px] font-['inter-Regular'] font-extrabold leading-snug sm:leading-tight md:leading-[1.1] tracking-tight mb-4 sm:mb-6 text-center bg-gradient-to-b from-white via-[#E4E0FF] to-[#BEB3FE] bg-clip-text text-transparent drop-shadow-[0_8px_30px_rgba(171,157,254,0.25)]">
          Crafting digital experiences
          <span className="block mt-1 sm:mt-2">
            that scale and inspire innovation.
          </span>
        </h1>
        <p className="text-sm sm:text-base md:text-lg lg:text-xl leading-relaxed mb-8 sm:mb-10 max-w-xl sm:max-w-2xl mx-auto text-[#B8BBD6] drop-shadow-[0_2px_8px_rgba(0,0,0,0.4)] px-2 sm:px-0">
          At Syfus, we design and develop web products that are fast, modern,
          and built to drive growth for startups and forward-thinking brands.
        </p>
        {/* Buttons - Responsive */}
        <div className="flex   items-center justify-center gap-3 sm:gap-4 mb-16 sm:mb-20">
          <MainButton text="Work With Us" />
          <button className="px-6 py-2.5 w-fit rounded-full text-sm sm:text-base text-white border border-[#30363D] bg-[#11121A]/60 backdrop-blur-sm hover:bg-zinc-900/50 transition-all duration-300">
            View Plans
          </button>
        </div>
      </div>
    </section>
  );
};

export default Hero;
