import React from "react";
import {
  ArrowUpRight,
  Sparkles,
  Code2,
  Bot,
  Palette,
  Layers,
} from "lucide-react";

import circle from "@/assets/images/Untitled-1.png";

const services = [
  {
    id: 1,
    title: "Frontend Development",
    subtitle: "Modern Interfaces",
    description:
      "Lightning-fast web apps with React, Next.js & TypeScript. Pixel-perfect, animated, and responsive.",
    icon: Code2,
    gradient: "from-[#6C4DFF] to-[#8A6CFF]",
    colSpan: "col-span-12 md:col-span-6 lg:col-span-4",
  },
  {
    id: 2,
    title: "Chatbot Development",
    subtitle: "AI Agents",
    description:
      "Intelligent conversational bots with OpenAI integration for automated support and lead generation.",
    icon: Bot,
    gradient: "from-[#8A6CFF] to-[#B4A5FF]",
    colSpan: "col-span-12 md:col-span-6 lg:col-span-4",
  },
  {
    id: 3,
    title: "UI/UX Design",
    subtitle: "User Experience",
    description:
      "Stunning, intuitive interfaces that convert. From wireframes to high-fidelity design systems.",
    icon: Palette,
    gradient: "from-[#B4A5FF] to-[#6C4DFF]",
    colSpan: "col-span-12 md:col-span-6 lg:col-span-4",
  },
  {
    id: 4,
    title: "Full Stack Apps",
    subtitle: "End-to-End",
    description:
      "Scalable SaaS solutions with auth, payments, database & cloud deployment ready for production.",
    icon: Layers,
    gradient: "from-[#6C4DFF] via-[#8A6CFF] to-[#B4A5FF]",
    colSpan: "col-span-12 md:col-span-12 lg:col-span-12",
  },
];

const ServiceCard = ({
  service,
  index,
}: {
  service: (typeof services)[0];
  index: number;
}) => {
  const isLast = index === services.length - 1;

  return (
    <div
      className={`group relative rounded-[24px] border border-white/[0.08] bg-[#11121A]/80 p-8 overflow-hidden hover:border-[#6C4DFF]/40 hover:bg-[#11121A] transition-all duration-500 ${service.colSpan} ${isLast ? "lg:p-10" : ""}`}
    >
      <div className="absolute top-0 right-0 w-[300px] h-[300px] bg-[#6C4DFF]/10 rounded-full blur-[80px] -translate-y-1/2 translate-x-1/2 group-hover:bg-[#6C4DFF]/20 transition-all duration-700" />

      <div className="absolute inset-0 bg-[linear-gradient(rgba(108,77,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(108,77,255,0.02)_1px,transparent_1px)] bg-[size:32px_32px] opacity-30" />

      <div className="relative z-10">
        <div className="flex items-center justify-between mb-8">
          <span className="text-5xl font-['b'] font-black text-white/[0.03] group-hover:text-[#6C4DFF]/10 transition-colors duration-500 select-none">
            0{index + 1}
          </span>
          <div className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center group-hover:border-[#6C4DFF]/50 group-hover:bg-[#6C4DFF]/10 transition-all duration-300">
            <ArrowUpRight className="w-4 h-4 text-white/40 group-hover:text-[#6C4DFF] group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all duration-300" />
          </div>
        </div>

        <div
          className={
            isLast ? "lg:flex lg:items-end lg:justify-between lg:gap-12" : ""
          }
        >
          <div className={isLast ? "lg:flex-1" : ""}>
            <span
              className={`text-xs font-bold uppercase tracking-[0.25em] bg-gradient-to-r ${service.gradient} bg-clip-text text-transparent mb-3 block`}
            >
              {service.subtitle}
            </span>

            <h3 className="text-2xl font-['b'] font-bold text-white mb-3 group-hover:text-[#E4E0FF] transition-colors duration-300">
              {service.title}
            </h3>

            <p className="text-[#8C90B5] text-sm leading-relaxed group-hover:text-[#B8BBD6] transition-colors duration-300 max-w-[320px]">
              {service.description}
            </p>
          </div>

          {isLast && (
            <div className="hidden lg:block text-right">
              <span className="text-[80px] font-['b'] font-black leading-none bg-gradient-to-r from-[#6C4DFF]/20 via-[#8A6CFF]/10 to-transparent bg-clip-text text-transparent">
                FULL
              </span>
            </div>
          )}
        </div>

        <div className="absolute -bottom-3  left-0 w-0 h-[2px] bg-gradient-to-r from-[#6C4DFF] to-[#8A6CFF] group-hover:w-full transition-all duration-700 ease-out" />
      </div>
    </div>
  );
};

export default function ServicesSection() {
  return (
    <section className="relative bg-[#0B0B12] py-24 px-4 sm:px-6 lg:px-8 ov">
      <div className="relative z-10 max-w-7xl mx-auto">
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between mb-16 gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-[#6C4DFF]/30 bg-[#6C4DFF]/10 text-[#8A6CFF] text-[10px] font-bold mb-4 uppercase tracking-[0.2em]">
              <Sparkles size={10} />
              Services
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-['b'] leading-[1.1] text-white">
              What we do
              <span className="block text-[#8C90B5] mt-1">best</span>
            </h2>
          </div>

          <p className="text-[#8C90B5] text-sm max-w-md leading-relaxed lg:text-right">
            Specialized in modern web technologies, AI integration, and scalable
            architecture for startups and growing businesses.
          </p>
        </div>

        <div className="grid grid-cols-12 gap-4">
          {services.map((service, index) => (
            <ServiceCard key={service.id} service={service} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
