import React from "react";
import { ArrowUpRight, ExternalLink } from "lucide-react";

function Project() {
  return (
    <section className="w-full min-h-screen bg-[#0B0B12] py-24 px-4 sm:px-6 lg:px-8 relative">
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-[#6C4DFF]/30 bg-[#6C4DFF]/10 text-[#8A6CFF] text-[10px] font-['a'] mb-6 uppercase tracking-[0.2em]">
            <span className="w-1.5 h-1.5 rounded-full bg-[#8A6CFF] animate-pulse" />
            Portfolio
          </div>

          <h2 className="text-4xl sm:text-5xl md:text-[56px] font-['b'] leading-[1.1] tracking-tight mb-6">
            <span className="bg-gradient-to-b from-white via-[#E4E0FF] to-[#BEB3FE] bg-clip-text text-transparent">
              Selected Work
            </span>
          </h2>

          <p className="text-[#8C90B5] text-lg max-w-xl font-['Inter-regular']">
            A collection of projects that showcase my expertise in building
            modern, high-performance web applications.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">

          {/* Project 1 */}
          <a
            href="https://steelframeai-client.vercel.app/"
            target="_blank"
            className="group relative rounded-[28px] overflow-hidden bg-[#11121A] border border-white/[0.08] hover:border-[#6C4DFF]/40 transition-all duration-500 cursor-pointer"
          >
            <div className="relative h-[400px] overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-t from-[#6C4DFF] to-[#8A6CFF] opacity-0 group-hover:opacity-20 transition-opacity duration-500 z-10" />
              <img
                src="https://images.unsplash.com/photo-1642104704074-907c0698cbd9"
                alt="STEELFRAMEAI"
                className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700 ease-out"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#11121A] via-[#11121A]/50 to-transparent z-20" />
              <div className="absolute top-6 right-6 z-30 w-12 h-12 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-300">
                <ArrowUpRight className="w-5 h-5 text-white" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 p-8 z-30">
              <div className="flex items-end justify-between">
                <div>
                  <span className="inline-block px-3 py-1 rounded-full bg-[#6C4DFF]/10 border border-[#6C4DFF]/20 text-[#8A6CFF] text-xs font-['a'] mb-3 uppercase tracking-wider">
                    AI Solutions
                  </span>
                  <h3 className="text-2xl md:text-3xl font-['c'] text-white group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:from-white group-hover:to-[#8A6CFF] group-hover:bg-clip-text transition-all duration-300">
                    STEELFRAMEAI
                  </h3>
                </div>
                <div className="hidden sm:flex items-center gap-2 text-[#8C90B5] font-['Inter-regular'] group-hover:text-[#8A6CFF] transition-colors duration-300">
                  <span className="text-sm">View</span>
                  <ExternalLink className="w-4 h-4" />
                </div>
              </div>
            </div>
            <div className="absolute -bottom-40 -right-40 w-80 h-80 bg-gradient-to-br from-[#6C4DFF] to-[#8A6CFF] opacity-0 group-hover:opacity-20 blur-[100px] transition-opacity duration-500 pointer-events-none" />
          </a>

          {/* Project 2 */}
          <a
            href="https://nova-zen-client.vercel.app/"
            target="_blank"
            className="group relative rounded-[28px] overflow-hidden bg-[#11121A] border border-white/[0.08] hover:border-[#6C4DFF]/40 transition-all duration-500 cursor-pointer"
          >
            <div className="relative h-[400px] overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-t from-[#8A6CFF] to-[#B4A5FF] opacity-0 group-hover:opacity-20 transition-opacity duration-500 z-10" />
              <img
                src="https://images.unsplash.com/photo-1620121692029-d088224ddc74"
                alt="NOVA ZEN"
                className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700 ease-out"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#11121A] via-[#11121A]/50 to-transparent z-20" />
              <div className="absolute top-6 right-6 z-30 w-12 h-12 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-300">
                <ArrowUpRight className="w-5 h-5 text-white" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 p-8 z-30">
              <div className="flex items-end justify-between">
                <div>
                  <span className="inline-block px-3 py-1 rounded-full bg-[#6C4DFF]/10 border border-[#6C4DFF]/20 text-[#8A6CFF] text-xs font-['a'] mb-3 uppercase tracking-wider">
                    Wellness
                  </span>
                  <h3 className="text-2xl md:text-3xl font-['c'] text-white group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:from-white group-hover:to-[#8A6CFF] group-hover:bg-clip-text transition-all duration-300">
                    NOVA ZEN
                  </h3>
                </div>
                <div className="hidden sm:flex items-center gap-2 text-[#8C90B5] font-['Inter-regular'] group-hover:text-[#8A6CFF] transition-colors duration-300">
                  <span className="text-sm">View</span>
                  <ExternalLink className="w-4 h-4" />
                </div>
              </div>
            </div>
            <div className="absolute -bottom-40 -right-40 w-80 h-80 bg-gradient-to-br from-[#8A6CFF] to-[#B4A5FF] opacity-0 group-hover:opacity-20 blur-[100px] transition-opacity duration-500 pointer-events-none" />
          </a>

          {/* Project 3 */}
          <a
            href="https://lumenstudio-client.vercel.app/"
            target="_blank"
            className="group relative rounded-[28px] overflow-hidden bg-[#11121A] border border-white/[0.08] hover:border-[#6C4DFF]/40 transition-all duration-500 cursor-pointer"
          >
            <div className="relative h-[400px] overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-t from-[#6C4DFF] to-[#A78BFA] opacity-0 group-hover:opacity-20 transition-opacity duration-500 z-10" />
              <img
                src="https://images.unsplash.com/photo-1638803040283-7a5ffd48dad5"
                alt="LUMENSTUDIO"
                className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700 ease-out"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#11121A] via-[#11121A]/50 to-transparent z-20" />
              <div className="absolute top-6 right-6 z-30 w-12 h-12 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-300">
                <ArrowUpRight className="w-5 h-5 text-white" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 p-8 z-30">
              <div className="flex items-end justify-between">
                <div>
                  <span className="inline-block px-3 py-1 rounded-full bg-[#6C4DFF]/10 border border-[#6C4DFF]/20 text-[#8A6CFF] text-xs font-['a'] mb-3 uppercase tracking-wider">
                    Creative Studio
                  </span>
                  <h3 className="text-2xl md:text-3xl font-['c'] text-white group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:from-white group-hover:to-[#8A6CFF] group-hover:bg-clip-text transition-all duration-300">
                    LUMENSTUDIO
                  </h3>
                </div>
                <div className="hidden sm:flex items-center gap-2 text-[#8C90B5] font-['Inter-regular'] group-hover:text-[#8A6CFF] transition-colors duration-300">
                  <span className="text-sm">View</span>
                  <ExternalLink className="w-4 h-4" />
                </div>
              </div>
            </div>
            <div className="absolute -bottom-40 -right-40 w-80 h-80 bg-gradient-to-br from-[#6C4DFF] to-[#A78BFA] opacity-0 group-hover:opacity-20 blur-[100px] transition-opacity duration-500 pointer-events-none" />
          </a>

          {/* Project 4 */}
          <a
            href="https://atlas-property-co-client.vercel.app/"
            target="_blank"
            className="group relative rounded-[28px] overflow-hidden bg-[#11121A] border border-white/[0.08] hover:border-[#6C4DFF]/40 transition-all duration-500 cursor-pointer"
          >
            <div className="relative h-[400px] overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-t from-[#7C3AED] to-[#8A6CFF] opacity-0 group-hover:opacity-20 transition-opacity duration-500 z-10" />
              <img
                src="https://i.pinimg.com/1200x/53/70/f3/5370f3d1d051204e4be54678de2c11ef.jpg"
                alt="ATLAS PROPERTY CO."
                className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700 ease-out"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#11121A] via-[#11121A]/50 to-transparent z-20" />
              <div className="absolute top-6 right-6 z-30 w-12 h-12 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-300">
                <ArrowUpRight className="w-5 h-5 text-white" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 p-8 z-30">
              <div className="flex items-end justify-between">
                <div>
                  <span className="inline-block px-3 py-1 rounded-full bg-[#6C4DFF]/10 border border-[#6C4DFF]/20 text-[#8A6CFF] text-xs font-['a'] mb-3 uppercase tracking-wider">
                    Real Estate
                  </span>
                  <h3 className="text-2xl md:text-3xl font-['c'] text-white group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:from-white group-hover:to-[#8A6CFF] group-hover:bg-clip-text transition-all duration-300">
                    ATLAS PROPERTY CO.
                  </h3>
                </div>
                <div className="hidden sm:flex items-center gap-2 text-[#8C90B5] font-['Inter-regular'] group-hover:text-[#8A6CFF] transition-colors duration-300">
                  <span className="text-sm">View</span>
                  <ExternalLink className="w-4 h-4" />
                </div>
              </div>
            </div>
            <div className="absolute -bottom-40 -right-40 w-80 h-80 bg-gradient-to-br from-[#7C3AED] to-[#8A6CFF] opacity-0 group-hover:opacity-20 blur-[100px] transition-opacity duration-500 pointer-events-none" />
          </a>

        </div>

        <div className="mt-16 text-center">
          <button className="group relative inline-flex items-center gap-3 px-8 py-4 rounded-full bg-transparent border border-[#6C4DFF]/30 text-white font-['c'] overflow-hidden hover:border-[#6C4DFF] transition-all duration-300">
            <span className="relative z-10">View All Projects</span>
            <ArrowUpRight className="w-5 h-5 relative z-10 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform duration-300" />
          </button>
        </div>

      </div>
    </section>
  );
}

export default Project;