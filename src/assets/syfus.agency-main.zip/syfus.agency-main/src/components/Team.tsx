import React from "react";
import saqib from "@/assets/images/s.png";
import huzaifa from "@/assets/images/h.png";
import usman from "@/assets/images/1767529253540_birefnet.png";

const teamMembers = [
  {
    id: 1,
    name: "Saqib Farhan",
    role: "Co-Founder - Lead Full Stack Software Developer",
    description:
      "I love turning complex problems into simple, beautiful solutions. Whether it's architecting scalable systems or crafting pixel-perfect interfaces, I bring ideas to life through code and creativity.",
    image: saqib.src,
    isFounder: true,
    socials: {
      linkedin: "#",
    },
  },
  {
    id: 2,
    name: "Huzaifa Faisal",
    role: "Co-Founder - Lead Full Stack Software Engineer",
    description:
      "Building products that people actually enjoy using is what drives me. I focus on writing clean, efficient code while making sure every interaction feels intuitive and seamless.",
    image: huzaifa.src,
    isFounder: true,
    socials: {
      linkedin: "#",
    },
  },
  {
    id: 3,
    name: "Muhammad Usman",
    role: "Frontend Developer & Content Manager",
    description:
      "There's something satisfying about seeing a design come alive in the browser. I specialize in creating responsive, performant interfaces that tell a story and keep users engaged.",
    image: usman.src,
    isFounder: false,
    socials: {
      linkedin: "#",
    },
  },
];

function Team() {
  return (
    <section className="w-full min-h-screen bg-[#0B0B12] py-16 sm:py-20 md:py-24 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute top-1/4 left-1/4 w-[300px] sm:w-[400px] md:w-[500px] h-[300px] sm:h-[400px] md:h-[500px] bg-[#6C4DFF]/10 rounded-full blur-[100px] md:blur-[150px]" />
      <div className="absolute bottom-1/4 right-1/4 w-[250px] sm:w-[300px] md:w-[400px] h-[250px] sm:h-[300px] md:h-[400px] bg-[#8A6CFF]/10 rounded-full blur-[80px] md:blur-[120px]" />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Header */}
        <div className="mb-12 sm:mb-16 md:mb-20">
          <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-[56px] font-['b'] leading-[1.1] tracking-tight mb-4 sm:mb-6">
            <span className="bg-gradient-to-b from-white via-[#E4E0FF] to-[#BEB3FE] bg-clip-text text-transparent">
              Our Team
            </span>
          </h2>

          <p className="text-[#8C90B5] text-base sm:text-lg max-w-2xl font-['Inter-regular'] leading-relaxed">
            Meet the talented professionals behind our success. Each member
            brings unique expertise and passion to create exceptional digital
            experiences.
          </p>
        </div>

        {/* Team Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {teamMembers.map((member) => (
            <div
              key={member.id}
              className="group relative rounded-[20px] sm:rounded-[24px] md:rounded-[28px] bg-[#11121A] border border-white/[0.08] overflow-hidden hover:border-[#6C4DFF]/40 transition-all duration-500 hover:-translate-y-2"
            >
              {/* Image Container */}
              <div className="relative h-[350px] sm:h-[400px] md:h-[450px] lg:h-[480px] overflow-hidden bg-gradient-to-b from-[#161822] via-[#0f1016] to-[#11121A]">
                {/* Background Pattern */}
                <img
                  src="https://i.pinimg.com/736x/7e/64/cb/7e64cb495c4ac775cd8e9da936cd345f.jpg"
                  className="absolute z-10 h-full w-full object-cover opacity-10"
                  alt=""
                />

                {/* Main Image */}
                <img
                  src={member.image}
                  alt={member.name}
                  className="absolute bottom-0 left-1/2 -translate-x-1/2 h-[95%] sm:h-[100%] w-auto object-contain z-20 transform group-hover:scale-105 transition-transform duration-700"
                />

                {/* Gradient Fade */}
                <div className="absolute bottom-0 left-0 right-0 h-32 sm:h-40 md:h-48 bg-gradient-to-t from-[#11121A] via-[#11121A]/80 to-transparent z-20" />
              </div>

              {/* Content */}
              <div className="p-5 sm:p-6 md:p-8 pt-3 sm:pt-4 relative z-30 bg-[#11121A]">
                {/* Role */}
                <p className="text-[#8A6CFF] text-[10px] sm:text-xs md:text-sm font-['Inter'] font-bold uppercase tracking-[0.15em] sm:tracking-[0.2em] mb-2">
                  {member.role}
                </p>

                {/* Name */}
                <h3 className="text-2xl sm:text-3xl md:text-4xl font-['c'] text-white mb-3 sm:mb-4 group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:from-white group-hover:to-[#8A6CFF] group-hover:bg-clip-text transition-all duration-300 leading-tight">
                  {member.name}
                </h3>

                {/* Description */}
                <div className="relative pl-3 sm:pl-4 border-l-2 border-[#6C4DFF]/30">
                  <p className="text-[#8C90B5] text-xs sm:text-sm font-['Inter-regular'] leading-relaxed">
                    {member.description}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Team;