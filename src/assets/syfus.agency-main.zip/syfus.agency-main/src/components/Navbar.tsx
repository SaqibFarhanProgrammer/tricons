"use client";
import React, { useState, useRef, useEffect } from "react";
import MainButton from "./MainButton";
import gsap from "gsap";
import logo from "@/assets/images/logo.png";

function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const menuItemsRef = useRef<Array<HTMLAnchorElement | null>>([]);

  const menuItems = [
    "Home",
    "Platform",
    "Solutions",
    "Enterprise",
    "Ad Network",
  ];

  useEffect(() => {
    if (!menuRef.current) return;

    if (isOpen) {
      gsap.to(menuRef.current, {
        duration: 0.3,
        opacity: 1,
        pointerEvents: "auto",
      });

      gsap.fromTo(
        menuItemsRef.current,
        { opacity: 0, y: 20 },
        { opacity: 1, y: 0, stagger: 0.1, duration: 0.4 },
      );
    } else {
      gsap.to(menuRef.current, {
        duration: 0.3,
        opacity: 0,
        pointerEvents: "none",
      });
    }
  }, [isOpen]);

  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-50 px-16 py-4 bg-gradient-to-b from-[#020104]/40 to-transparent backdrop-blur-md">
        <div className="flex items-center justify-between">
          <div className="text-white text-2xl uppercase font-['inter']">
            syfus
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center gap-8">
            {menuItems.map((item) => (
              <a
                key={item}
                href="#"
                className="text-white hover:text-gray-300 transition-colors text-sm font-medium"
              >
                {item}
              </a>
            ))}
          </div>

          {/* Buttons + Hamburger */}
          <div className="flex items-center gap-4">
            <div className="hidden md:block">
              <MainButton text="Work With Us" />
            </div>

            <button
              className="md:hidden text-white focus:outline-none z-50 relative"
              onClick={() => setIsOpen(!isOpen)}
            >
              {isOpen ? (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              ) : (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M4 8h16M4 16h16"
                  />
                </svg>
              )}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Fullscreen Menu */}
      <div
        ref={menuRef}
        className="fixed inset-0 w-full h-screen bg-black/70 backdrop-blur-[20px] flex flex-col items-center justify-center opacity-0 pointer-events-none z-40"
      >
        {menuItems.map((item, index) => (
          <a
            key={item}
            href="#"
            ref={(el) => {
              menuItemsRef.current[index] = el;
            }}
            className="text-white text-3xl font-semibold hover:text-gray-300 transition-all my-4"
            onClick={() => setIsOpen(false)}
          >
            {item}
          </a>
        ))}
      </div>
    </>
  );
}

export default Navbar;
