"use client";

import dynamic from "next/dynamic";
import React from "react";

// Dynamic import for MainButton (if it uses any client-only code)
const MainButton = dynamic(() => import("./MainButton"), { ssr: false });

// CTA Section
export function CTASection() {
  return (
    <section className="w-full bg-[#0B0B12] py-32 relative">
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="-mt-[6vw]">
          <h3 className="text-4xl md:text-6xl lg:text-7xl font-['c'] text-white mb-6 leading-[1.1]">
            Let's build
            <br />
            <span className="bg-gradient-to-r from-[#6C4DFF] via-[#8A6CFF] to-[#B4A5FF] bg-clip-text text-transparent">
              something great
            </span>
          </h3>

          <p className="text-[#8C90B5] text-lg md:text-xl max-w-2xl mx-auto font-['Inter-regular'] leading-relaxed mb-10">
            Ready to transform your digital presence? We're here to help you
            create exceptional experiences that drive results.
          </p>

          <MainButton text="Start A Project" />
        </div>
      </div>
    </section>
  );
}

// Footer Section
export function Footer() {
  return (
    <footer className="w-full bg-[#0B0B12] relative overflow-hidden">
      <div className="relative z-10 max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="relative flex flex-col items-center justify-center mb-16">
          <div className="absolute inset-0 flex -bottom-150 items-center justify-center">
            <div className="w-[80vw] h-[40vw] bg-[#6C4DFF]/20 rounded-full blur-[120px]" />
          </div>

          <h1 className="relative text-[20vw] md:text-[18vw] lg:text-[15vw] font-['b'] leading-[0.8] tracking-tighter bg-gradient-to-b from-white via-[#E4E0FF] to-[#8A6CFF] bg-clip-text text-transparent">
            SYFUS
          </h1>

          <div className="w-32 h-1 bg-gradient-to-r from-transparent via-[#6C4DFF] to-transparent mt-8 opacity-60" />
        </div>

        <div className="flex flex-col md:flex-row items-center justify-between gap-6 pt-8 border-t border-white/[0.06]">
          <p className="text-[#8C90B5] text-sm font-['Inter-regular']">
            © 2024 Tricons. All rights reserved.
          </p>

          <div className="flex items-center gap-8">
            <a
              href="#"
              className="text-[#8C90B5] text-sm font-['Inter-regular'] hover:text-[#8A6CFF] transition-colors duration-300"
            >
              Privacy
            </a>
            <a
              href="#"
              className="text-[#8C90B5] text-sm font-['Inter-regular'] hover:text-[#8A6CFF] transition-colors duration-300"
            >
              Terms
            </a>
            <a
              href="#"
              className="text-[#8C90B5] text-sm font-['Inter-regular'] hover:text-[#8A6CFF] transition-colors duration-300"
            >
              Contact
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}

// Combined export for convenience
export default function CTAFooter() {
  return (
    <>
      <CTASection />
      <Footer />
    </>
  );
}