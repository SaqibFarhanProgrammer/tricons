import React from "react";
import { ArrowUpRight } from "lucide-react";

export function CTASection() { 
  return (
    <section className="w-full bg-[#0B0B12] relative overflow-hidden py-24 sm:py-28 lg:py-32">
      {/* Background Gradient Image */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://i.pinimg.com/1200x/24/aa/81/24aa81993e2b9eea3ca75eab3293ebbf.jpg"
          alt=""
          className="w-full h-full object-cover opacity-20"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0B0B12] via-[#0B0B12]/80 to-transparent" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Background Tricons Text */}
        <h2 className="text-[12vw] sm:text-[10vw] md:text-[8vw] lg:text-[6vw] font-['b'] leading-[0.8] tracking-tighter text-white/[0.03] select-none mb-6 sm:mb-8">
          SYFUS AGENCY
        </h2>

        {/* Main Heading */}
        <div className="-mt-[5vw] sm:-mt-[4vw] md:-mt-[3vw]">
          <h3 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-['c'] text-white mb-6 leading-snug sm:leading-[1.1]">
            Let's build
            <br />
            <span className="bg-gradient-to-r from-[#6C4DFF] via-[#8A6CFF] to-[#B4A5FF] bg-clip-text text-transparent">
              something great
            </span>
          </h3>

          <p className="text-[#8C90B5] text-base sm:text-lg md:text-xl max-w-full sm:max-w-xl md:max-w-2xl mx-auto font-['Inter-regular'] leading-relaxed mb-8 sm:mb-10">
            Ready to transform your digital presence? We're here to help you
            create exceptional experiences that drive results.
          </p>

          {/* CTA Button */}
          <button className="group relative inline-flex items-center gap-3 px-6 sm:px-8 md:px-10 py-3 sm:py-4 md:py-5 rounded-full bg-[#6C4DFF] text-white font-['Inter'] font-bold text-base sm:text-lg md:text-xl overflow-hidden transition-all duration-300 hover:shadow-[0_0_60px_rgba(108,77,255,0.5)] hover:scale-105">
            <span className="relative z-10">Start a Project</span>
            <ArrowUpRight className="w-4 sm:w-5 h-4 sm:h-5 relative z-10 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform duration-300" />

            {/* Glow Effects */}
            <div className="absolute inset-0 bg-gradient-to-r from-[#8A6CFF] to-[#6C4DFF] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            <div className="absolute -inset-2 bg-[#6C4DFF] blur-2xl opacity-0 group-hover:opacity-50 transition-opacity duration-500" />
          </button>
        </div>
      </div>
    </section>
  );
}