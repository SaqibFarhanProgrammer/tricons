import React from "react";


interface MainButtonProps {
  text: string;
}

function MainButton( {text}: MainButtonProps ) {
  return (
    <button
      className="
            inline-flex items-center justify-center
            rounded-full
            px-6 py-2.5
            text-black font-medium
            transition-all duration-300
            active:scale-95
            border border-[#BEB3FE]/60

            shadow-[0px_2px_0px_0px_rgba(255,255,255,0.5)_inset,
                     0px_-8px_6px_0px_rgba(0,0,0,0.5)_inset,
                     0px_8px_16px_0px_rgba(47,41,100,0.6)]

            [background:radial-gradient(60%_120%_at_50%_120%,#2F2964_0%,#AB9DFE_70%,#BEB3FE_100%)]

            hover:-translate-y-[2px]
            "
    >
      {text}
    </button>
  );
}

export default MainButton;
