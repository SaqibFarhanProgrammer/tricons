import React from "react";
import Image from "next/image";
import { Sparkles, ArrowUpRight } from "lucide-react";
import servicebg from "@/assets/images/servicesbg.png";

const States = () => {
  return (
    <section className="relative bg-[#0B0B12] py-28 px-4 sm:px-6 lg:px-8 ">
      <Image
        src={servicebg}
        alt=""
        className="absolute z-10 bottom-20 hue-rotate-5 left-0 h-[150vh] w-[150vw] blur-[90px]"
      />

      <div className="relative z-10 max-w-6xl mx-auto">
        <div className="text-center mb-20">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-white/10 bg-white/[0.05] text-[#8A6CFF] text-[10px] font-bold mb-6 uppercase tracking-[0.2em]">
            <Sparkles size={10} /> Our Impact
          </div>

          <h1 className="text-4xl sm:text-5xl md:text-[46px] font-['b'] leading-[1.1] tracking-tight mb-6 bg-gradient-to-b from-white via-[#E4E0FF] to-[#BEB3FE] bg-clip-text text-transparent">
            Numbers that represent
            <span className="block mt-2">real development work</span>
          </h1>
        </div>

        <div className="grid grid-cols-12 gap-2 auto-rows-[280px] z-50">
          <div className="col-span-12 lg:col-span-6 relative rounded-[28px] border border-[#6C4DFF]/30 bg-[#11121A] p-10 overflow-hidden group">
            <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-[#6C4DFF]/20 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2 group-hover:bg-[#6C4DFF]/30 transition-all duration-700" />
            <div className="absolute bottom-0 left-0 w-[300px] h-[300px] bg-[#8A6CFF]/10 rounded-full blur-[80px] translate-y-1/2 -translate-x-1/2" />

            <div className="relative  z-10 h-full flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-[#6C4DFF] text-xs font-bold uppercase tracking-[0.2em]">
                  Projects
                </span>
                <ArrowUpRight className="w-5 h-5 text-[#6C4DFF] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </div>

          
            </div>

            <div className="absolute inset-0 rounded-[28px] border border-[#6C4DFF]/0 group-hover:border-[#6C4DFF]/50 transition-all duration-500" />
          </div>

          <div className="col-span-12 lg:col-span-6 relative rounded-[28px] border border-white/10 bg-[#11121A] p-10 overflow-hidden group hover:border-[#6C4DFF]/30 transition-all duration-500">
            <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-[#6C4DFF]/15 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2 group-hover:bg-[#6C4DFF]/25 transition-all duration-700" />
            <div className="absolute bottom-0 left-0 w-[250px] h-[250px] bg-[#8A6CFF]/10 rounded-full blur-[60px] translate-y-1/2 -translate-x-1/2" />

            <div className="relative z-10 h-full flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-[#8A6CFF] text-xs font-bold uppercase tracking-[0.2em]">
                  Experience
                </span>
                <ArrowUpRight className="w-5 h-5 text-[#8A6CFF] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </div>

              <div>
                <h2 className="text-7xl md:text-8xl font-['b'] font-black mb-4 bg-gradient-to-br from-white via-[#E4E0FF] to-[#8A6CFF] bg-clip-text text-transparent leading-none">
                  5+
                </h2>
                <p className="text-[#8C90B5] text-base max-w-[300px] leading-relaxed">
                  Professional experience delivering modern web products and
                  production ready systems.
                </p>
              </div>
            </div>
          </div>

          <div className="col-span-12 lg:col-span-5 relative rounded-[28px] border border-white/10 bg-[#11121A] p-10 overflow-hidden group hover:border-[#6C4DFF]/30 transition-all duration-500">
            <div className="absolute top-0 right-0 w-[350px] h-[350px] bg-[#6C4DFF]/15 rounded-full blur-[90px] -translate-y-1/2 translate-x-1/2 group-hover:bg-[#6C4DFF]/25 transition-all duration-700" />
            <div className="absolute bottom-0 left-0 w-[200px] h-[200px] bg-[#8A6CFF]/10 rounded-full blur-[50px] translate-y-1/2 -translate-x-1/2" />

            <div className="relative z-10 h-full flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-[#8A6CFF] text-xs font-bold uppercase tracking-[0.2em]">
                  Performance
                </span>
                <ArrowUpRight className="w-5 h-5 text-[#8A6CFF] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </div>

              <div>
                <h2 className="text-7xl md:text-8xl font-['b'] font-black mb-4 bg-gradient-to-br from-white via-[#E4E0FF] to-[#8A6CFF] bg-clip-text text-transparent leading-none">
                  20%
                </h2>
                <p className="text-[#8C90B5] text-base max-w-[260px] leading-relaxed">
                  Faster applications built with optimized modern frontend
                  architecture.
                </p>
              </div>
            </div>
          </div>

          <div className="col-span-12 lg:col-span-7 relative rounded-[28px] border border-white/10 bg-[#11121A] p-10 overflow-hidden group hover:border-[#6C4DFF]/30 max-[420px]:h-[40vh] transition-all duration-500">
            <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-[#6C4DFF]/12 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/3 group-hover:bg-[#6C4DFF]/20 transition-all duration-700" />
            <div className="absolute bottom-0 left-0 w-[300px] h-[300px] bg-[#8A6CFF]/10 rounded-full blur-[70px] translate-y-1/2 -translate-x-1/4" />

            <div className="absolute inset-0 bg-[linear-gradient(rgba(108,77,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(108,77,255,0.03)_1px,transparent_1px)] bg-[size:40px_40px] opacity-30" />

            <div className="relative z-10  h-full max-[420px]: flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-[#8A6CFF] text-xs font-bold uppercase tracking-[0.2em]">
                  Services
                </span>
                <ArrowUpRight className="w-5 h-5 text-[#8A6CFF] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </div>

              <div>
                <h2 className="text-4xl md:text-5xl font-['b'] font-bold mb-4 bg-gradient-to-br from-white via-[#E4E0FF] to-[#8A6CFF] bg-clip-text text-transparent leading-tight">
                  We Built Modern Era
                  <br />
                  Websites
                </h2>
                <p className="text-[#8C90B5] text-base max-w-[380px] leading-relaxed">
                  Clean UI systems, scalable architecture and high performance
                  websites built for the modern internet.
                </p>
              </div>
            </div>

            <div className="absolute top-10 right-10 w-20 h-20 border border-[#6C4DFF]/20 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            <div className="absolute top-16 right-16 w-10 h-10 border border-[#6C4DFF]/30 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-100" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default States;
