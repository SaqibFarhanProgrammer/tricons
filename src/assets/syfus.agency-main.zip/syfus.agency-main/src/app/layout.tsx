import type { Metadata } from "next";
import { Inter, Poppins } from "next/font/google";
import "./globals.css";


import fav from "@/assets/images/favicon.jpeg"
export const metadata: Metadata = {
  title: "Syfus",
  icons:fav.src
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={`antialiased`}
       cz-shortcut-listen="true">
        {children}
      </body>
    </html>

  );
}