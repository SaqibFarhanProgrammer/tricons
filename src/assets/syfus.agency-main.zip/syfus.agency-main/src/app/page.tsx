import { CTASection } from "@/components/CTA";
import { Footer } from "@/components/Footer";
import Hero from "@/components/Hero";
import Project from "@/components/Project";
import SmoothScroll from "@/components/SmoothScroll";
import ServicesSection from "@/components/Services";
import States from "@/components/States";

export default function Page() {
  return (
    <div className="">
      <SmoothScroll>
        <Hero />
        <States/>
        <Project />
        <ServicesSection/>  
        <CTASection />
        <Footer />
      </SmoothScroll>
    </div>
    // 
  );
}
